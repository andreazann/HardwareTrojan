Compila con gcc -o aes *.c
Esegui con ./aes input_small.asc output_small.enc e 1234567890abcdeffedcba09876543211234567890abcdeffedcba0987654321
