compila con gcc -o susan *.c
Esegui con ./susan
