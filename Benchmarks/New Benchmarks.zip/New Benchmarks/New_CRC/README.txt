Compila con gcc -o crc *.c
Eseguui con ./crc small.pcm
