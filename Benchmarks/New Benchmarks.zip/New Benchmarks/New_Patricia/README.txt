Compila con gcc -o patricia *.c
Esegui ./patricia small.udp
