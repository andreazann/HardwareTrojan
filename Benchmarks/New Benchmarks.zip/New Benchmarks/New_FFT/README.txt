compila con gcc -o FFT *.c -lm
esegui con ./FFT 4 8192 -i
