#!/bin/bash

gdb --batch -x gdb_script --args a.out $1