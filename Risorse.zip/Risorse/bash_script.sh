#!/bin/bash

gdb --batch -x gdb_script a.out